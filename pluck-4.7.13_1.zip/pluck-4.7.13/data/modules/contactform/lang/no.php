<?php
$lang['contactform']['module_name'] = 'kontaktskjema';
$lang['contactform']['module_intro'] = 'med et kontaktskjema kan du gi dine besøkende muligheten til å sende deg en beskjed';
$lang['contactform']['fields'] = 'Du fylte ikke inn alle feltene korrekt.';
$lang['contactform']['email_title'] = 'Melding fra nettsiden din fra';
$lang['contactform']['been_send'] = 'Meldingen din ble sendt korrekt.';
$lang['contactform']['not_send'] = 'Meldingen din kunne ikke sendes, det oppsto en feil.';
?>