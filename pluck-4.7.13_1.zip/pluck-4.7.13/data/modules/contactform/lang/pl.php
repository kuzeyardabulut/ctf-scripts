<?php
$lang['contactform']['module_name']	= 'formularz kontaktowy';
$lang['contactform']['module_intro']	= 'poprzez formularz kontaktowy, pozwalasz swoim gościom na wysyłanie Ci wiadomości';
$lang['contactform']['fields']	= 'Nie wypełniłeś poprawnie wszystkich pól.';
$lang['contactform']['email_title']	= 'Wiadomość z formularza kontaktowego';
$lang['contactform']['been_send']	= 'Wiadomość została wysłana pomyślnie.';
$lang['contactform']['not_send']	= 'Twoja wiadomość nie mogła być wysłana, nastąpił błąd.';
?>