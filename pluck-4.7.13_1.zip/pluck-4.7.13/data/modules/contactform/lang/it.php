<?php
$lang['contactform']['module_name'] = 'contact form';
$lang['contactform']['module_intro'] = 'with a contact form, you can allow your visitors to send you a message';
$lang['contactform']['fields'] = 'Non avete inserito i dati correttamente.';
$lang['contactform']['email_title'] = 'Messagio dal vs. sito web da parte di';
$lang['contactform']['been_send'] = 'Messaggio spedito.';
$lang['contactform']['not_send'] = 'Messaggio non spedito, si è verificato un errore';
?>