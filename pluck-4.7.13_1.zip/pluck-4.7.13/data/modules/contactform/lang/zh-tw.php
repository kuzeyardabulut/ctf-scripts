<?php
$lang['contactform']['module_name'] = '聯絡表格';
$lang['contactform']['module_intro'] = '通過聯絡表格，你可以讓參觀者寄訊息給你。';
$lang['contactform']['fields'] = '你並沒有正確地輸入所有項目。';
$lang['contactform']['email_title'] = '由你網站所來的訊息';
$lang['contactform']['been_send'] = '你的訊息已成功寄出。';
$lang['contactform']['not_send'] = '你的訊息不能寄出：發生錯誤。';
?>