<?php
$lang['albums']['title'] = 'albums';
$lang['albums']['descr'] = 'usa gli albums gli albums per mostrare ai visitatori le vs. foto o immagini';
$lang['albums']['message'] = 'Qui potete gestire i vs. albums. Usate gli albums per mostrare ai visitatori le vs. foto o immagini. Inserite gli albmus nell vs. pagine scegliendo "inserisci album" quando create/modificate una pagina.';
$lang['albums']['edit_albums'] = 'modifica albums';
$lang['albums']['new_album'] = 'nuovo album';
$lang['albums']['choose_name'] = 'scegli priam una nome per l\'album, poi clicca su "salva"';
$lang['albums']['delete_album'] = 'elimina album';
$lang['albums']['edit_album'] = 'modifica album';
$lang['albums']['album_message1'] = 'Usa questa pagina per aggiungere, eliminare and modificare le immagini degli album. Solo immagini <b>JPG</b> supportate.';
$lang['albums']['album_message2'] = 'upload nuova immagine qui. Scegli titolo e descrizione, poi scegli al qualità alla quale deve essere processata. Maggiore la qualit`, maggiore sarà il peso del file.';
$lang['albums']['edit_images'] = 'modifica immagini';
$lang['albums']['new_image'] = 'nuove immagini';
$lang['albums']['quality'] = 'qualità (1-100)';
$lang['albums']['edit_image'] = 'modifica immagine';
$lang['albums']['doesnt_exist'] = 'l\'album specificato non esiste.';
$lang['albums']['name_exist'] = 'There is already an album with that name.';
$lang['albums']['image_exist'] = 'There is already an image with that name.';
$lang['albums']['change_order'] = 'cambia ordine alle immagini';
$lang['albums']['already_top'] = 'Questa immagine è già la prima della lista.';
$lang['albums']['already_last'] = 'Questa immagine è già l\'ultima della lista';
$lang['albums']['delete_image'] = 'cancella immagine';
$lang['albums']['image_width'] = 'The width in pixels the images will be resized to. Choose 0 to disable automatic resizing.';
$lang['albums']['thumb_width'] = 'The width in pixels the thumbnails will be resized to. Cannot be disabled.';
$lang['albums']['settings_error'] = 'The width of the resized images should be numeric.';
?>