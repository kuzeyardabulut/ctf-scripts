<?php
$lang['viewsite']['module_name'] = 'veure l\'enllaç al lloc web';
$lang['viewsite']['module_intro'] = 'Creat per a mostrar els enllaços als desenvolupadors dels mòduls. Afegeix un enllaç directe al lloc en el menú d\'aministració. ';
$lang['viewsite']['message'] = 'veure el lloc web';
?>