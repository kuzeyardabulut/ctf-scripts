<?php
$lang['viewsite']['module_name'] = 'Seite anzeigen Verknüpfung';
$lang['viewsite']['module_intro'] = 'Erstellt um Entwicklern Modul-Haken zu demonstrieren. Fügt einen direkten Link zur Seite im Admin-Menü hinzu.';
$lang['viewsite']['message'] = 'Seite anzeigen';
?>