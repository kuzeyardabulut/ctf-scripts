<?php
$lang['contactform']['module_name'] = 'Formular de contact';
$lang['contactform']['module_intro'] = 'Prin intermediul unui formalar de contact veți oferii vizitatorilor posibilitatea de a vă trimite mesaje.';
$lang['contactform']['fields'] = 'Nu ați introdus toate câmpurile obligatorii.';
$lang['contactform']['email_title'] = 'Mesaj de pe forumarul de contact';
$lang['contactform']['been_send'] = 'Mesajul dumneavoastră a fost trimis cu succes.';
$lang['contactform']['not_send'] = 'S-a produs o eroare iar mesajul dumneavoastră nu a putut fi trimis.';
?>