<?php
$lang['contactform']['module_name'] = 'kontakt formulär';
$lang['contactform']['module_intro'] = 'med hjälp av ett kontakt formulär kan dina besökare skicka medelanden till dig';
$lang['contactform']['fields'] = 'Du har inte fyllt i alla fält på ett korrekt sätt.';
$lang['contactform']['email_title'] = 'Meddelande från din hemsida';
$lang['contactform']['been_send'] = 'Ditt meddelande har skickats.';
$lang['contactform']['not_send'] = 'Ditt meddelande kunde inte skickas, ett fel har uppstått.';
?>