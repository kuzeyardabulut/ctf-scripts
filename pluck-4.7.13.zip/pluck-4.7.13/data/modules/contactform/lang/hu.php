<?php
$lang['contactform']['module_name'] = 'kapcsolatfelvétel';
$lang['contactform']['module_intro'] = 'a kapcsolatfelvétel modullal biztosíthatod látogatóidnak, hogy felvegyék veled a kapcsolatot';
$lang['contactform']['fields'] = 'Nem töltöttél ki minden mezőt megfelelően.';
$lang['contactform']['email_title'] = 'Üzenet a honlapodról:';
$lang['contactform']['been_send'] = 'Üzeneted elküldtük.';
$lang['contactform']['not_send'] = 'Üzeneted nem küldtük el, hiba történt.';
?>