<?php
$lang['contactform']['module_name'] = '問い合わせフォーム';
$lang['contactform']['module_intro'] = 'with a contact form, you can allow your visitors to send you a message';
$lang['contactform']['fields'] = '全ての項目をうめていません.';
$lang['contactform']['email_title'] = 'ウェブサイトからのメッセージ';
$lang['contactform']['been_send'] = 'あなたのメッセージの送信に成功しました。';
$lang['contactform']['not_send'] = 'エラーが発生しました。メールの送信に失敗しました。';
?>